Openstack Management Framework


